import { LANGS, getLang, tr, trf } from '../i18n';
import { useEffect, useRef, useState } from 'react';
import { Icon, MAP_ICONS, type IconName } from './Icon';
import { ScooterPreview } from './ScooterPreview';
import { effMu, staticSag, stoppingDistance } from '../game/calc';
import {
  BRAKES,
  DEFAULT_TUNE,
  MAPS,
  MODELS,
  PADS,
  PRESETS,
  SURFACES,
  SURFACE_ORDER,
  TIRES,
  defaultLook,
  presetForSurface,
  type BrakeType,
  type Look,
  type ModelId,
  type PadId,
  type Settings,
  type SurfaceId,
  type TireId,
  type Tune,
} from '../game/data';
import { cn } from '../utils/cn';
import { Bar, ColorField, Section, Seg, Slider, Stat, Toggle } from './primitives';

type TabId = 'model' | 'susp' | 'brake' | 'rider' | 'game';
const TABS: { id: TabId; label: string; icon: IconName }[] = [
  { id: 'model', icon: 'scooter', label: 'Самокат' },
  { id: 'susp', icon: 'spring', label: 'Подвеска' },
  { id: 'brake', icon: 'brake', label: 'Тормоза' },
  { id: 'rider', icon: 'rider', label: 'Райдер' },
  { id: 'game', icon: 'settings', label: 'Игра' },
];

export type GarageFocusPart = 'all' | 'front' | 'rear' | 'cockpit' | 'deck';

interface Props {
  look: Look;
  tune: Tune;
  settings: Settings;
  surface: SurfaceId;
  updLook: (p: Partial<Look>) => void;
  setLook: (l: Look) => void;
  updTune: (p: Partial<Tune>) => void;
  updSet: (p: Partial<Settings>) => void;
  onClose: () => void;
  onPreviewChange?: (active: boolean) => void;
  onRespawn: () => void;
  onFocusPart?: (part: GarageFocusPart) => void;
}

function PresetBar({ surface, tune, updTune }: { surface: SurfaceId; tune: Tune; updTune: (p: Partial<Tune>) => void }) {
  const rec = presetForSurface(surface);
  const isActive = (p: (typeof PRESETS)[number]) => (Object.keys(p.tune) as (keyof Tune)[]).every(k => tune[k] === p.tune[k]);
  return <Section icon="road" title={tr('Профиль покрытия')} hint={tr('Быстрая настройка')}>
    <div className="preset-list">{PRESETS.map(p => <button key={p.id} aria-pressed={isActive(p)} onClick={() => updTune(p.tune)}>{tr(p.name)}{p.id === rec.id && <span className="recommended-dot" title={tr('Рекомендуется для текущего покрытия')}/>}</button>)}<button onClick={() => updTune(DEFAULT_TUNE)}><Icon name="reset" size={14}/> {tr('Сброс')}</button></div>
    <p className="field-hint">{tr('Оранжевая точка — профиль для текущего покрытия.')}</p>
  </Section>;
}

function ModelTab({ look, updLook, setLook, onFocusPart, activePart }: Pick<Props, 'look' | 'updLook' | 'setLook' | 'onFocusPart'> & { activePart: GarageFocusPart }) {
  const m = MODELS[look.model];
  const pick = (id: ModelId) => setLook({ ...defaultLook(id), helmet: look.helmet, helmetColor: look.helmetColor, jacket: look.jacket, pants: look.pants, skin: look.skin, fender: look.fender, glow: look.glow });
  return <>
    <Section icon="scooter" title={tr('Выберите модель')} hint="01 — 05">
      <div className="model-list">{Object.values(MODELS).map((mm, i) => <button key={mm.id} aria-pressed={mm.id === look.model} onClick={() => pick(mm.id)}>
        <span className="model-index">0{i + 1}</span><span className="model-info"><strong>{mm.name.replace('Kukirin ', '')}</strong><span>{mm.power} {tr('Вт ·')} {mm.awd ? tr('Полный привод') : tr('Задний привод')}</span></span><span className="model-speed">{mm.vmax}<small>{tr('км/ч')}</small></span><span className="selection-mark"/>
      </button>)}</div>
      <p className="model-description">{tr(m.desc)}</p>
      <div className="model-specs"><Stat icon="battery" label={tr('Батарея')} value={`${Math.round(m.battWh)} ${tr('Вт·ч')}`}/><Stat icon="weight" label={tr('Масса')} value={`${m.mass} ${tr('кг')}`}/><Stat icon="wheel" label={tr('Колёса')} value={`${m.defaultWheel}″`}/></div>
      <div className="mode-specs">{(['eco', 'drive', 'sport'] as const).map(mode => <div key={mode}><span>{mode.toUpperCase()}</span><strong>{m.modeSpeeds[mode]} <small>{tr('км/ч')}</small></strong></div>)}</div>
      {onFocusPart && <div className="inspection-links">{([['all', tr('Общий вид')], ['front', tr('Вилка')], ['rear', tr('Маятник')], ['cockpit', tr('Руль')], ['deck', tr('Дека')]] as [GarageFocusPart, string][]).map(([id, label]) => <button key={id} aria-pressed={activePart === id} onClick={() => onFocusPart(id)}><Icon name={id === 'all' ? 'scooter' : id === 'cockpit' ? 'steering' : id === 'deck' ? 'sliders' : 'wheel'} size={14}/>{label}</button>)}</div>}
    </Section>
    <Section icon="palette" title={tr('Цвета')}>
      <ColorField label={tr('Рама и дека')} value={look.frame} onChange={frame => updLook({ frame })}/>
      <ColorField label={tr('Акценты')} value={look.accent} onChange={accent => updLook({ accent, glowColor: accent })}/>
      <ColorField label={tr('Стойка и руль')} value={look.stem} onChange={stem => updLook({ stem })}/>
      <ColorField label={tr('Диски колёс')} value={look.rim} onChange={rim => updLook({ rim })}/>
    </Section>
    <Section icon="wheel" title={tr('Колёса и шины')}>
      <Seg options={[8.5, 9, 10, 11, 12].map(value => ({ value, label: `${value}″` }))} value={look.wheel} onChange={wheel => updLook({ wheel })}/>
      <p className="field-hint">{trf('У модели {model} штатные колёса {size}″. Другие размеры — тюнинг.', { model: m.name.replace('Kukirin ', ''), size: m.defaultWheel })}</p>
      <div className="option-list">{Object.values(TIRES).map(t => <button key={t.id} aria-pressed={look.tire === t.id} onClick={() => updLook({ tire: t.id as TireId })}><strong>{tr(t.name)}</strong><span>{tr(t.desc)}</span></button>)}</div>
    </Section>
    <Section icon="light" title={tr('Обвес и свет')}>
      <Toggle icon="wheel" label={tr('Крылья')} value={look.fender} onChange={fender => updLook({ fender })}/>
      <Toggle icon="light" label={tr('Подсветка деки')} value={look.glow} onChange={glow => updLook({ glow })}/>
      {look.glow && <ColorField label={tr('Подсветка')} value={look.glowColor} onChange={glowColor => updLook({ glowColor })}/>}
      <ColorField label={tr('Свет фары')} value={look.lightColor} onChange={lightColor => updLook({ lightColor })}/>
    </Section>
  </>;
}

function GripTable({ tire, fPsi, rPsi, surface }: { tire: TireId; fPsi: number; rPsi: number; surface: SurfaceId }) {
  return (
    <div className="space-y-1">
      {SURFACE_ORDER.map((s) => {
        const mu = effMu(s, tire, (fPsi + rPsi) / 2);
        return (
          <div key={s} className={cn('flex items-center gap-2 text-[11px]', s === surface && 'text-orange-300')}>
            
            <span className="w-28 truncate">{tr(SURFACES[s].name)}</span>
            <Bar value={mu / 1.1} className="flex-1" color={mu > 0.75 ? 'bg-emerald-400' : mu > 0.45 ? 'bg-amber-400' : 'bg-red-400'} />
            <span className="w-8 text-right font-mono tabular-nums">{mu.toFixed(2)}</span>
          </div>
        );
      })}
    </div>
  );
}

function SuspTab({ look, tune, settings, surface, updTune }: Pick<Props, 'look' | 'tune' | 'settings' | 'surface' | 'updTune'>) {
  const sag = staticSag(look.model, settings.riderKg, tune);
  const sagColor = (p: number) => (p > 0.45 ? 'text-red-300' : p < 0.12 ? 'text-amber-300' : 'text-emerald-300');
  return (
    <>
      <PresetBar surface={surface} tune={tune} updTune={updTune} />

      <Section icon="spring" title={tr('Передняя подвеска')} hint={trf('ход {n} мм', { n: (MODELS[look.model].travel * 1000).toFixed(0) })}>
        <Slider label={tr('Жёсткость пружины')} value={tune.fSpring} min={10} max={60} unit={tr(' Н/мм')} onChange={(v) => updTune({ fSpring: v })} />
        <Slider label={tr('Преднатяг')} value={tune.fPre} min={0} max={25} unit={tr(' мм')} onChange={(v) => updTune({ fPre: v })} />
        <Slider label={tr('Демпфер: сжатие')} value={tune.fComp} min={0} max={100} unit="%" onChange={(v) => updTune({ fComp: v })} hint={tr('Выше — жёстче на ударах, меньше клюёт на тормозе')} />
        <Slider label={tr('Демпфер: отбой')} value={tune.fReb} min={0} max={100} unit="%" onChange={(v) => updTune({ fReb: v })} hint={tr('Выше — медленнее возвращается, меньше «пого»')} />
      </Section>

      <Section icon="spring" title={tr('Задняя подвеска')}>
        <Slider label={tr('Жёсткость пружины')} value={tune.rSpring} min={10} max={60} unit={tr(' Н/мм')} onChange={(v) => updTune({ rSpring: v })} />
        <Slider label={tr('Преднатяг')} value={tune.rPre} min={0} max={25} unit={tr(' мм')} onChange={(v) => updTune({ rPre: v })} />
        <Slider label={tr('Демпфер: сжатие')} value={tune.rComp} min={0} max={100} unit="%" onChange={(v) => updTune({ rComp: v })} />
        <Slider label={tr('Демпфер: отбой')} value={tune.rReb} min={0} max={100} unit="%" onChange={(v) => updTune({ rReb: v })} />
      </Section>

      <Section icon="chart" title={tr('Анализ настройки')} hint={trf('вес райдера {n} кг', { n: settings.riderKg })}>
        <div className="grid grid-cols-2 gap-1.5">
          <Stat label={tr('Просадка (SAG) пер.')} value={<span className={sagColor(sag.pctF)}>{sag.sagF.toFixed(0)} {tr('мм ·')} {(sag.pctF * 100).toFixed(0)}%</span>} />
          <Stat label={tr('Просадка (SAG) зад.')} value={<span className={sagColor(sag.pctR)}>{sag.sagR.toFixed(0)} {tr('мм ·')} {(sag.pctR * 100).toFixed(0)}%</span>} />
          <Stat label={tr('Частота пер.')} value={`${sag.freqF.toFixed(1)} ${tr('Гц')}`} />
          <Stat label={tr('Частота зад.')} value={`${sag.freqR.toFixed(1)} ${tr('Гц')}`} />
        </div>
        <p className="text-[10px] text-zinc-500">{tr('Идеальный SAG — 20–35% хода. Если пружина «пробивает» (красная полоса на HUD) — повысьте жёсткость или демпфирование сжатия.')}</p>
      </Section>

      <Section icon="steering" title={tr('Руль')}>
        <Slider label={tr('Рулевой демпфер')} value={tune.steerDamper} min={0} max={100} unit="%" onChange={(v) => updTune({ steerDamper: v })} hint={tr('Гасит быстрые рывки руля на скорости')} />
        <Slider label={tr('Чувствительность руля')} value={tune.steerSens} min={50} max={150} unit="%" onChange={(v) => updTune({ steerSens: v })} />
      </Section>

      <Section icon="gauge" title={tr('Давление в шинах')} hint="psi">
        <Slider label={tr('Переднее')} value={tune.fPsi} min={12} max={50} unit=" psi" onChange={(v) => updTune({ fPsi: v })} />
        <Slider label={tr('Заднее')} value={tune.rPsi} min={12} max={50} unit=" psi" onChange={(v) => updTune({ rPsi: v })} />
        <div className="text-[10px] text-zinc-400">{trf('Эффективное сцепление ({tire}):', { tire: tr(TIRES[look.tire].name) })}</div>
        <GripTable tire={look.tire} fPsi={tune.fPsi} rPsi={tune.rPsi} surface={surface} />
      </Section>
    </>
  );
}

function BrakeTab({ look, tune, settings, surface, updTune }: Pick<Props, 'look' | 'tune' | 'settings' | 'surface' | 'updTune'>) {
  const mass = MODELS[look.model].mass + settings.riderKg;
  const dist = SURFACE_ORDER.map((s) => ({ s, d: stoppingDistance(s, look.tire, look.wheel, tune, mass) }));
  const maxD = Math.max(...dist.map((x) => x.d));
  const mu = effMu(surface, look.tire, (tune.fPsi + tune.rPsi) / 2);
  const idealBias = Math.round((0.45 + 0.2 * mu) * 100);
  return (
    <>
      <PresetBar surface={surface} tune={tune} updTune={updTune} />

      <Section icon="brake" title={tr('Тормозная система')}>
        <Seg<BrakeType>
          small
          options={(Object.keys(BRAKES) as BrakeType[]).map((k) => ({ value: k, label: tr(BRAKES[k].name.replace('Гидравлика, ', 'Гидр. ').replace('Механика (тросик)', 'Механика')) }))}
          value={tune.brakeType}
          onChange={(v) => updTune({ brakeType: v })}
        />
        <p className="text-[10px] text-zinc-500">{tr(BRAKES[tune.brakeType].desc)}</p>
        <div>
          <div className="text-[13px] text-zinc-300 mb-1">{tr('Диаметр роторов')}</div>
          <Seg options={[{ value: 140, label: tr('140 мм') }, { value: 160, label: tr('160 мм') }, { value: 180, label: tr('180 мм') }]} value={tune.rotor} onChange={(v) => updTune({ rotor: v as 140 | 160 | 180 })} />
        </div>
        <div>
          <div className="text-[13px] text-zinc-300 mb-1">{tr('Колодки')}</div>
          <Seg<PadId>
            small
            options={(Object.keys(PADS) as PadId[]).map((k) => ({ value: k, label: tr(PADS[k].name.split(' ')[0]) }))}
            value={tune.pad}
            onChange={(v) => updTune({ pad: v })}
          />
          <p className="text-[10px] text-zinc-500 mt-1">{tr(PADS[tune.pad].desc)} {tr('Перегрев с')} {PADS[tune.pad].fadeStart}°C.</p>
        </div>
      </Section>

      <Section icon="sliders" title={tr('Распределение и рычаг')}>
        <Slider label={tr('Баланс (перед / зад) для общего тормоза')} value={tune.bias} min={0} max={100} unit={tr('% перед')} onChange={(v) => updTune({ bias: v })} hint={trf('На текущем покрытии оптимально ≈ {n}% на переднее колесо', { n: idealBias })} />
        <Slider label={tr('Прогрессивность рычага')} value={tune.curve} min={0.6} max={2.2} step={0.05} decimals={2} onChange={(v) => updTune({ curve: v })} hint={tr('Выше — мягкое начало, резкое в конце хода (лучше на скользком)')} />
      </Section>

      <Section icon="battery" title={tr('Электроника')}>
        <Slider label={tr('Рекуперация')} value={tune.regen} min={0} max={100} unit="%" onChange={(v) => updTune({ regen: v })} hint={tr('Тормозит задним мотором при сбросе газа и торможении')} />
        <Toggle icon="shield" label="ABS" value={tune.abs} onChange={(v) => updTune({ abs: v })} hint={tr('Предотвращает блокировку колёс')} />
        {tune.abs && <Slider label={tr('Порог ABS (проскальзывание)')} value={tune.absThr} min={5} max={30} unit="%" onChange={(v) => updTune({ absThr: v })} hint={tr('Низкий — для льда и воды; высокий — для гравия и песка')} />}
        <Toggle icon="shield" label={tr('Антибуксовка (TCS)')} value={tune.tcs} onChange={(v) => updTune({ tcs: v })} hint={tr('Режет тягу при пробуксовке')} />
      </Section>

      <Section icon="road" title={tr('Тормозной путь с 30 км/ч')} hint={tr('оценка')}>
        <div className="space-y-1">
          {dist.map(({ s, d }) => (
            <div key={s} className={cn('flex items-center gap-2 text-[11px]', s === surface && 'text-orange-300')}>
              
              <span className="w-28 truncate">{tr(SURFACES[s].name)}</span>
              <Bar value={d / maxD} className="flex-1" color={d < 7 ? 'bg-emerald-400' : d < 12 ? 'bg-amber-400' : 'bg-red-400'} />
              <span className="w-12 text-right font-mono tabular-nums">{d.toFixed(1)} {tr('м')}</span>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}

function RiderTab({ look, settings, updLook, updSet }: Pick<Props, 'look' | 'settings' | 'updLook' | 'updSet'>) {
  return (
    <>
      <Section icon="weight" title={tr('Вес райдера')}>
        <Slider label={tr('Вес')} value={settings.riderKg} min={45} max={120} unit={tr(' кг')} onChange={(v) => updSet({ riderKg: v })} hint={tr('Влияет на динамику, просадку подвески и тормозной путь')} />
      </Section>
      <Section icon="helmet" title={tr('Шлем')}>
        <Seg
          options={[{ value: 'none', label: tr('Без') }, { value: 'open', label: tr('Открытый') }, { value: 'full', label: tr('Интеграл') }]}
          value={look.helmet}
          onChange={(v) => updLook({ helmet: v })}
        />
        {look.helmet !== 'none' && <ColorField label={tr('Цвет шлема')} value={look.helmetColor} onChange={(v) => updLook({ helmetColor: v })} />}
      </Section>
      <Section icon="shirt" title={tr('Экипировка')}>
        <ColorField label={tr('Куртка')} value={look.jacket} onChange={(v) => updLook({ jacket: v })} />
        <ColorField label={tr('Штаны')} value={look.pants} onChange={(v) => updLook({ pants: v })} />
        <div>
          <div className="text-[13px] text-zinc-300 mb-1.5">{tr('Тон кожи')}</div>
          <div className="flex gap-2">
            {['#f3cfb3', '#e0ac86', '#c68863', '#9a6a45', '#6b4429', '#3f2716'].map((c) => (
              <button key={c} onClick={() => updLook({ skin: c })} aria-label={trf('Тон кожи {c}', { c })} className={cn('w-8 h-8 rounded-full ring-2', look.skin === c ? 'ring-orange-400' : 'ring-white/15')} style={{ background: c }} />
            ))}
          </div>
        </div>
      </Section>
    </>
  );
}

function GameTab({ settings, updSet, onRespawn }: Pick<Props, 'settings' | 'updSet' | 'onRespawn'>) {
  const keys: [string, string][] = [
    ['W / ↑', tr('газ')],
    ['Shift / F', tr(' стант (езда на заднем колесе)')],
    [`S / ↓ / ${tr('Пробел')}`, tr('тормоз (оба) / задний ход')],
    ['Z / X', tr('передний / задний тормоз (X гасит перекрут станта)')],
    ['A D / ← →', tr('руль (в т.ч. подруливание в станте)')],
    ['Q / E', tr('вес назад (выше угол станта) / вперёд')],
    ['C', tr('камера 1-е / 3-е лицо')],
    ['M', tr('режим ECO / DRIVE / SPORT')],
    ['N', tr('сменить карту')],
    ['P', tr('повтор аварии со слоумо')],
    ['V', tr('сменить ракурс камеры в повторе')],
    ['G / Esc', tr('гараж и настройки')],
    ['R', tr('поднять после падения')],
  ];
  return (
    <>
      <Section icon="info" title={tr('Язык')} hint="Language · Język">
        <Seg options={LANGS.map(l => ({ value: l.id, label: l.label }))} value={getLang()} onChange={(lang) => updSet({ lang })} />
      </Section>
      <Section icon="city" title={tr('Локация')}>
        <div className="option-list">{Object.values(MAPS).map(mp => <button key={mp.id} aria-pressed={(settings.map ?? 'city') === mp.id} onClick={() => updSet({ map: mp.id })}><strong className="option-heading"><Icon name={MAP_ICONS[mp.id]} size={18}/>{tr(mp.shortName)}</strong><span>{tr(mp.desc)}</span></button>)}</div>
      </Section>
      <Section icon="camera" title={tr('Камера')}>
        <Seg options={[{ value: 'tpv', label: tr('От третьего лица') }, { value: 'fpv', label: tr('От первого лица') }]} value={settings.camera} onChange={(v) => updSet({ camera: v })} />
        <p className="text-[10px] text-zinc-500">{tr('Во время езды потяните по экрану, чтобы осмотреться.')}</p>
      </Section>
      <Section icon="motor" title={tr('Режим мотора')}>
        <Seg options={[{ value: 'eco', label: 'ECO' }, { value: 'drive', label: 'DRIVE' }, { value: 'sport', label: 'SPORT' }]} value={settings.mode} onChange={(v) => updSet({ mode: v })} />
      </Section>
      <Section icon="sun" title={tr('Окружение')}>
        <Seg options={[{ value: 'day', label: tr('День') }, { value: 'sunset', label: tr('Закат') }, { value: 'night', label: tr('Ночь') }]} value={settings.time} onChange={(v) => updSet({ time: v })} />
        <div>
          <div className="inline-field-heading"><Icon name="sliders" size={16}/>{tr('Графика')}</div>
          <Seg options={[{ value: 'low', label: tr('Низкая') }, { value: 'med', label: tr('Средняя') }, { value: 'high', label: tr('Высокая') }]} value={settings.quality} onChange={(v) => updSet({ quality: v })} />
        </div>
      </Section>
      <Section icon="settings" title={tr('Геймплей')}>
        <Toggle icon="rider" label={tr('Падения и 3D-рэгдолл')} value={settings.crash} onChange={(v) => updSet({ crash: v })} hint={tr('Вылет райдера (рэгдолл) при столкновении на скорости + авто-повтор со слоумо')} />
        <Toggle icon="shield" label={tr('Рентген повреждений')} value={settings.xray} onChange={(v) => updSet({ xray: v })} hint={tr('В повторе аварии: скелет, сломанные кости и список травм')} />
        <Toggle icon="road" label={tr('Авто-профиль покрытия')} value={settings.autoProfile} onChange={(v) => updSet({ autoProfile: v })} hint={tr('Подвеска и тормоза подстраиваются под покрытие')} />
        <Toggle icon="sound" label={tr('Звук')} value={settings.sound} onChange={(v) => updSet({ sound: v })} />
        <Toggle icon="gauge" label={tr('Мили в час')} value={settings.mph} onChange={(v) => updSet({ mph: v })} />
        <div>
          <div className="inline-field-heading"><Icon name="touch" size={16}/>{tr('Сенсорное управление')}</div>
          <Seg options={[{ value: 'auto', label: tr('Авто') }, { value: 'on', label: tr('Вкл') }, { value: 'off', label: tr('Выкл') }]} value={settings.touch} onChange={(v) => updSet({ touch: v })} />
        </div>
        <button onClick={onRespawn} className="w-full rounded-lg bg-white/10 hover:bg-white/20 py-2 text-[13px] font-semibold">
          {tr('↩ Вернуться на старт и зарядить батарею')}
        </button>
      </Section>
      <Section icon="keyboard" title={tr('Управление')}>
        <div className="text-[12px] space-y-1">
          {keys.map(([k, v]) => (
            <div key={k} className="flex justify-between gap-2">
              <kbd className="px-1.5 rounded bg-black/50 ring-1 ring-white/15 font-mono text-[11px] text-orange-300">{k}</kbd>
              <span className="text-zinc-400 text-right">{v}</span>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-zinc-400 pt-1">
           {tr('На телефоне: левый джойстик — руль (←→) и перенос веса (↑↓), справа — газ и тормоз. Для станта удерживайте газ и переносите вес назад.')}
        </p>
      </Section>
      <Section icon="info" title={tr('Подсказки по физике и станту')}>
        <ul className="text-[11px] text-zinc-400 space-y-1 list-disc pl-4">
          <li>
            <strong className="text-orange-300">{tr('Стант (езда на заднем колесе):')}</strong> {tr('зажмите')} <kbd className="px-1 rounded bg-white/10">W</kbd> + <kbd className="px-1 rounded bg-white/10">Shift</kbd>{tr('. Райдер встаёт задней ногой на упор и держит баланс в зелёной зоне (19°–37°, множитель очков ×2).')}
          </li>
          <li>
            {tr('Чтобы задрать угол выше до высекания искр задним крылом (>36°), потяните вес назад (')}<kbd className="px-1 rounded bg-white/10">Q</kbd>{tr('). Если угол уходит в красную зону (>42°), коротко нажмите задний тормоз (')}<kbd className="px-1 rounded bg-white/10">X</kbd>{tr('), чтобы не перевернуться назад!')}
          </li>
          <li>{tr('На мокром, снегу и песке тормозите задним колесом и плавно — передний тормоз может сорвать колесо в занос.')}</li>
          <li>{tr('Слишком сильный передний тормоз на сухом асфальте поднимает заднее колесо — это «стоппи» и падение через руль.')}</li>
          <li>
            <strong className="text-orange-300">{tr('Рэгдолл и повтор со слоумо:')}</strong> {tr('при столкновении на большой скорости с препятствием или машиной райдер вылетает из седла по законам 3D-физики, после чего автоматически включается кинематографический повтор со слоумо (')}<kbd className="px-1 rounded bg-white/10">P</kbd>).
          </li>
        </ul>
      </Section>
    </>
  );
}

export function Garage(props: Props) {
  const [tab, setTab] = useState<TabId>('model');
  const [previewPart, setPreviewPart] = useState<GarageFocusPart>('all');
  const { look, tune, settings, surface, onPreviewChange } = props;
  const closeRef = useRef<HTMLButtonElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => { closeRef.current?.focus({ preventScroll: true }); }, []);
  useEffect(() => { scrollRef.current?.scrollTo(0, 0); }, [tab]);
  useEffect(() => { setPreviewPart('all'); }, [look.model]);
  useEffect(() => {
    onPreviewChange?.(tab === 'model');
    return () => onPreviewChange?.(false);
  }, [tab, onPreviewChange]);
  return <div className="garage-layout">
    {tab === 'model' && <ScooterPreview look={look} tune={tune} part={previewPart} onReset={() => setPreviewPart('all')}/>}
    <div className="garage-brand"><span>KUKIRIN</span><span>{tr('СИМУЛЯТОР')}</span></div>
    {tab !== 'model' && <div className="garage-caption"><span className="eyebrow">{tr('Ваш самокат')}</span><h2>{MODELS[look.model].name.replace('Kukirin ', '')}</h2><span>{tr('Потяните, чтобы осмотреть')}</span></div>}
    <aside className="garage-panel" aria-label={tr('Гараж и настройки')}>
      <header className="garage-header"><div><span className="eyebrow">KUKIRIN SIM</span><h1>{tr('Гараж')}</h1></div><div className="language-switch" role="group" aria-label={tr('Язык')}>{LANGS.map(l => <button key={l.id} aria-pressed={getLang() === l.id} title={l.label} onClick={() => props.updSet({ lang: l.id })}>{l.short}</button>)}</div><button ref={closeRef} className="close-button" onClick={props.onClose} aria-label={tr('Закрыть гараж')}><Icon name="close"/></button></header>
      <nav className="garage-tabs" aria-label={tr('Разделы гаража')}>{TABS.map(t => <button key={t.id} aria-current={tab === t.id ? 'page' : undefined} onClick={() => setTab(t.id)}><Icon name={t.icon} size={19}/><span>{tr(t.label)}</span></button>)}</nav>
      <div ref={scrollRef} className="garage-content">
        {tab === 'model' && <ModelTab look={look} updLook={props.updLook} setLook={props.setLook} onFocusPart={setPreviewPart} activePart={previewPart}/>}
        {tab === 'susp' && <SuspTab look={look} tune={tune} settings={settings} surface={surface} updTune={props.updTune}/>}
        {tab === 'brake' && <BrakeTab look={look} tune={tune} settings={settings} surface={surface} updTune={props.updTune}/>}
        {tab === 'rider' && <RiderTab look={look} settings={settings} updLook={props.updLook} updSet={props.updSet}/>}
        {tab === 'game' && <GameTab settings={settings} updSet={props.updSet} onRespawn={props.onRespawn}/>}
      </div>
      <footer className="garage-footer"><div><Icon name={MAP_ICONS[settings.map ?? 'city']} size={18}/><span>{tr(MAPS[settings.map ?? 'city'].shortName)}</span><span className="footer-mode">{settings.mode.toUpperCase()}</span></div><button className="primary-button" onClick={props.onClose}>{tr('Ехать')} <Icon name="arrow" size={21}/></button></footer>
    </aside>
  </div>;
}
